import React, { Component } from "react";
import "./ProductList.css";

class ProductList extends Component {
  addtoCart(item) {
    this.props.add(item);
  }

  render() {
    return (
      <div>
        <div className="row">
          {this.props.products.map(product => (
            <div className="col-md-4" key={product.productName}>
              <div className="card">
                <img
                  src={product.productImage}
                  alt="Avatar"
                  className="productImage"
                />
                <div className="container">
                  <h4>
                    <b>{product.productName}</b>
                  </h4>
                  <p>
                    <b>${product.price}</b>
                  </p>
                  <button
                    className="btn btn-danger"
                    onClick={() => this.addtoCart(product)}
                  >
                    + Add to Cart
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

export default ProductList;
