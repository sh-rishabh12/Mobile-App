import React, { Component } from "react";
import data from "./Data.json";
import ProductList from "./ProductList/ProductList";
import ShoppingCart from "./ShoppingCart/ShoppingCart";
import "./App.css";

const APPDATA = data;

class App extends Component {
  state = { productList: [], shoppingCart: [] };

  componentWillMount() {
    this.setState({ productList: APPDATA.filter(d => d.isPublished) });
  }

  addtoCart = item => {
    let productItems = [...this.state.productList];
    let shoppingItems = [...this.state.shoppingCart, item];
    this.setState({
      productList: productItems.filter(x => x.productName !== item.productName),
      shoppingCart: shoppingItems
    });
  };

  removeFromCart = item => {
    let productItems = [...this.state.productList, item];
    let shoppingItems = [...this.state.shoppingCart];
    this.setState({
      productList: productItems,
      shoppingCart: shoppingItems.filter(
        x => x.productName !== item.productName
      )
    });
  };

  render() {
    console.log(this.state.productList);
    console.log(this.state.shoppingCart);
    return (
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-9 col-12 card list-items">
            <h3 className="header">Product List</h3>
            <ProductList
              products={this.state.productList}
              add={this.addtoCart}
            />
          </div>
          <div className="col-md-3 card list-items">
            <h3 className="header">Shopping Cart</h3>
            <ShoppingCart
              cart={this.state.shoppingCart}
              remove={this.removeFromCart}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
