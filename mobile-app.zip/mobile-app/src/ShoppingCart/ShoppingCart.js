import React, { Component } from "react";
import "./ShoppingCart.css";

class ShoppingCart extends Component {
  removeFromCart(item) {
    this.props.remove(item);
  }

  render() {
    return (
      <div>
        {this.props.cart.map(item => (
          <div className="card" key={item.productName}>
            <div className="container">
              <div className="row">
                <b className="products col-8">{item.productName}</b>
                <button
                  className="btn btn-danger col-4"
                  onClick={() => this.removeFromCart(item)}
                >
                  Remove
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
}

export default ShoppingCart;
